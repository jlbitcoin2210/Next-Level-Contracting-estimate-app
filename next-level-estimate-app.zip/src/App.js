import React from 'react';
import EstimateForm from './EstimateForm';

function App() {
  return <EstimateForm />;
}

export default App;